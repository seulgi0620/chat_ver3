package chat.client;

import chat.client.view.LoginView2;

public class main_Client {
	public static void main(String[] args) {
		
		new LoginView2();
		
	}
}