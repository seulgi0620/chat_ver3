package chat.client.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import chat.client.event.CreatingRoom;
import chat.client.method.MemLogic;
import chat.util.DBConnectionMgr;

@SuppressWarnings("serial")
public class FriendsPage extends JPanel implements ActionListener {
	
	public UserMainFrame umf     = null;
	
	public String user_id        = null;
	public String user_name      = null;
	
	DBConnectionMgr dbMgr = new DBConnectionMgr();
	Connection conn = null;
	PreparedStatement pstm = null;
	ResultSet rs = null;
	
	JButton jbt_add_friend = new JButton("ģ���߰�!");
	public JButton jbtn_start_chat = new JButton("�游���");
	
	JLabel jl_icon = new JLabel();
	
	ImageIcon icon_search = new ImageIcon("src/chat/imgs/search.png");
	JLabel jl_search = new JLabel("�̸��˻�");
	JTextField tf_search = new JTextField ();
	
	JButton jl_profile = new JButton();
	ImageIcon img5 = new ImageIcon(MemLogic.mvo.getPath());
	Image p = img5.getImage();
	Image img_profile = p.getScaledInstance(50, 50, java.awt.Image.SCALE_SMOOTH);
	ImageIcon icon_profile = new ImageIcon(img_profile);
	JLabel jl_myName = new JLabel(MemLogic.mvo.getM_name());
	
	String cols_friends[] = {"�� ģ���� ����"};
	String cols_search[] = {"�˻��� ���̵�","�̸�"};
	String data_friends[][] = new String[0][1];
	String data_search[][] = new String[0][1];
	DefaultTableModel dtm_myfriends = new DefaultTableModel(data_friends,cols_friends);
	DefaultTableModel dtm_search = new DefaultTableModel(data_search,cols_search);
	public JTable jt_myfriends = new JTable(dtm_myfriends);
	public JTable jt_search = new JTable(dtm_search);
	JScrollPane myfriendsScroll = new JScrollPane(jt_myfriends,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTableHeader header = jt_myfriends.getTableHeader();
	JScrollPane searchScroll = new JScrollPane(jt_search,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTableHeader header_search = jt_search.getTableHeader();
	
	Font f = new Font("���� ����",Font.PLAIN,13);  

	public FriendsPage(UserMainFrame umf, String m_ID){
		
		this.umf = umf;
		
		this.user_id = m_ID;
		
		setLayout(null);
		setBackground(Color.WHITE);
	
		jl_profile.addActionListener(this);
		tf_search.addActionListener(this);
		jbt_add_friend.addActionListener(this);
		
		CreatingRoom er = new CreatingRoom(this);
		jbtn_start_chat.addActionListener(er);
		
		jbtn_start_chat.setBounds(200, 55, 50, 50);
		
		jl_search.setBounds(40,10,160,30);
		jl_search.setFont(f);
		jl_search.setForeground(Color.LIGHT_GRAY);
		
		tf_search.setBounds(40,10,300,30);
		
		jl_profile.setBorderPainted(false);
		jl_profile.setFocusPainted(false);
		jl_profile.setContentAreaFilled(false);
		jl_profile.setBounds(20,55,icon_profile.getIconWidth(),icon_profile.getIconHeight());
		jl_profile.setIcon(icon_profile);
		
		jl_myName.setBounds(85,65,60,30);
		jl_myName.setFont(f);
		
		jbt_add_friend.setBounds(130,440,120,30);
		
		myfriendsScroll.setBounds(10,120,365,320);
		searchScroll.setBounds(10,120,365,320);
		header.setReorderingAllowed(false);
	
		add(jbtn_start_chat);
		add(jl_search);
		add(tf_search);	      
		add(myfriendsScroll);
		add(searchScroll);
		add(jl_profile);
		add(jbt_add_friend);
		add(jl_myName);
	
		friendsTable(m_ID);
	
	}
   
	public void friendsTable(String m_ID) {
		
		remove(searchScroll);
		add(myfriendsScroll);
		
		int row = dtm_myfriends.getRowCount();
		
		if(row>0) {
			for (int i = row- 1; i >= 0; i--) {
				dtm_myfriends.removeRow(i);
			}
		}
		
		try {
			
			conn = dbMgr.getConnection("chat_ver2");
			
			String sql = "select friend_id from chat_friend where user_id = ?";
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, m_ID);
			rs = pstm.executeQuery();
			
			while(rs.next()){
				Vector<String> v_f = new Vector<String>();
				String friend_name = rs.getString("friend_id");
				v_f.add(friend_name);
				dtm_myfriends.addRow(v_f);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
	
	}

	public void searchTable(String s_ID) {
		
		remove(myfriendsScroll);
		add(searchScroll);
		
		int row = dtm_search.getRowCount();
		
		if(row>0) {
			for (int i = row- 1; i >= 0; i--) {
				dtm_search.removeRow(i);
			}
		}
		
		try {
			
			conn = dbMgr.getConnection("chat_ver2");
			
			String sql = "  select user_id, user_name from chat_user  " + 
			"  where user_id like '%' || ? || '%'  "+ 
			"  and user_id != ?  " + 
			"  minus  "+ 
			"  select friend_id , friend_name from chat_friend "+ 
			"  where user_id= ? ";
			pstm = conn.prepareStatement(sql);
			pstm.setString(1, s_ID);
			pstm.setString(2, user_id);
			pstm.setString(3, user_id);
			rs = pstm.executeQuery();
			
			while(rs.next()){
				Vector<String> v_s = new Vector<String>();
				String user_id = rs.getString("user_id");
				String user_name = rs.getString("user_name");
				v_s.add(user_id);
				v_s.add(user_name);
				dtm_search.addRow(v_s);
			}
			
		} catch (SQLException sqle) {
			System.out.println("SELECT������ ���� �߻�");
			sqle.printStackTrace();
		}
		
	}


	public void actionPerformed(ActionEvent e){
		
		Object obj = e.getSource();
		
		if(obj==jl_profile || obj==jl_myName) {
			
			Profile p = new Profile();
			p.setVisible(true);
			
		} else if(obj == jbtn_start_chat) {
			
		} else if(obj==tf_search) {
			
			searchTable(tf_search.getText());
			
		} else if(obj==jbt_add_friend) {
			
			int row = jt_search.getSelectedRow();
			Object value = jt_search.getValueAt(row, 0);
			String svalue = (String) value;
			
			try {
				
				conn = dbMgr.getConnection("chat_ver2");
				String sql = "select user_id, user_name from chat_user  "
				+ "  where user_id = ?  ";
				pstm = conn.prepareStatement(sql);
				pstm.setString(1, svalue);
				rs = pstm.executeQuery();
				
				Vector<String> v_s = new Vector<String>();
				String user_id=null;
				String user_name=null;
				
				while(rs.next()){
					user_id = rs.getString("user_id");
					user_name = rs.getString("user_name");
					v_s.add(user_id);
					v_s.add(user_name);
				}
				
				String sql1 = "insert into chat_friend (friend_id, friend_name, user_id) "
				+ "values (?,?,?)";
				pstm = conn.prepareStatement(sql1);
				pstm.setString(1, user_id);
				pstm.setString(2, user_name);
				pstm.setString(3, this.user_id);
				pstm.executeUpdate();
				
				friendsTable(this.user_id);
				
			} catch (SQLException e2) {
				e2.printStackTrace();
			}
		}
	}

}